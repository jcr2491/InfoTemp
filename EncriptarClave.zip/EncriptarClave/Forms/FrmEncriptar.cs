﻿using System.Windows.Forms;
using EncriptarClave.Core;

namespace EncriptarClave.Forms
{
    public partial class FrmEncriptar : Form
    {
        public FrmEncriptar()
        {
            InitializeComponent();
        }

        #region Eventos

        private void btnEncriptar_Click(object sender, System.EventArgs e)
        {
            EncriptarClave();
        }

        #endregion

        #region Métodos

        private void EncriptarClave()
        {
            string clave = txtClave.Text.Trim();

            if (clave == string.Empty)
            {
                MessageBox.Show("Ingrese una clave", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            txtClaveEncriptada.Text = Encriptador.Encriptar(clave);
        }

        #endregion
    }
}