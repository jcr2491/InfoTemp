﻿namespace EncriptarClave.Forms
{
    partial class FrmEncriptar
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtClave = new System.Windows.Forms.TextBox();
            this.lblClave = new System.Windows.Forms.Label();
            this.lblClaveEncriptada = new System.Windows.Forms.Label();
            this.txtClaveEncriptada = new System.Windows.Forms.TextBox();
            this.btnEncriptar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtClave
            // 
            this.txtClave.Location = new System.Drawing.Point(15, 48);
            this.txtClave.Name = "txtClave";
            this.txtClave.Size = new System.Drawing.Size(385, 20);
            this.txtClave.TabIndex = 0;
            // 
            // lblClave
            // 
            this.lblClave.AutoSize = true;
            this.lblClave.Location = new System.Drawing.Point(12, 32);
            this.lblClave.Name = "lblClave";
            this.lblClave.Size = new System.Drawing.Size(34, 13);
            this.lblClave.TabIndex = 1;
            this.lblClave.Text = "Clave";
            // 
            // lblClaveEncriptada
            // 
            this.lblClaveEncriptada.AutoSize = true;
            this.lblClaveEncriptada.Location = new System.Drawing.Point(12, 82);
            this.lblClaveEncriptada.Name = "lblClaveEncriptada";
            this.lblClaveEncriptada.Size = new System.Drawing.Size(87, 13);
            this.lblClaveEncriptada.TabIndex = 3;
            this.lblClaveEncriptada.Text = "Clave encriptada";
            // 
            // txtClaveEncriptada
            // 
            this.txtClaveEncriptada.Location = new System.Drawing.Point(15, 98);
            this.txtClaveEncriptada.Multiline = true;
            this.txtClaveEncriptada.Name = "txtClaveEncriptada";
            this.txtClaveEncriptada.ReadOnly = true;
            this.txtClaveEncriptada.Size = new System.Drawing.Size(385, 107);
            this.txtClaveEncriptada.TabIndex = 2;
            // 
            // btnEncriptar
            // 
            this.btnEncriptar.Location = new System.Drawing.Point(294, 213);
            this.btnEncriptar.Name = "btnEncriptar";
            this.btnEncriptar.Size = new System.Drawing.Size(106, 44);
            this.btnEncriptar.TabIndex = 4;
            this.btnEncriptar.Text = "Encriptar Clave";
            this.btnEncriptar.UseVisualStyleBackColor = true;
            this.btnEncriptar.Click += new System.EventHandler(this.btnEncriptar_Click);
            // 
            // FrmEncriptar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(413, 262);
            this.Controls.Add(this.btnEncriptar);
            this.Controls.Add(this.lblClaveEncriptada);
            this.Controls.Add(this.txtClaveEncriptada);
            this.Controls.Add(this.lblClave);
            this.Controls.Add(this.txtClave);
            this.MinimizeBox = false;
            this.Name = "FrmEncriptar";
            this.Text = "EncriptarClave";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtClave;
        private System.Windows.Forms.Label lblClave;
        private System.Windows.Forms.Label lblClaveEncriptada;
        private System.Windows.Forms.TextBox txtClaveEncriptada;
        private System.Windows.Forms.Button btnEncriptar;
    }
}

